package com.nofrisdan.rekamsuara;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.io.File;
import java.io.IOException;

public class RecordActivity extends Activity {
    private Button rekam, stopr, putar, stopp;
    private TextView txt;
    private MediaPlayer mp;
    private MediaRecorder mr;
    private String tempat;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rekam);
        tempat = Environment.getExternalStorageDirectory() + "/hasilRekam.3gpp";
        txt = (TextView)findViewById(R.id.button1);
        rekam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startRekam();
                txt.setText("Sedang Merekam...");
                rekam.setEnabled(false);
                stopr.setEnabled(true);
                putar.setEnabled(false);
                stopp.setEnabled(false);

            }
        });

        stopr = (Button)findViewById(R.id.button2);
        stopr.setEnabled(false);
        stopr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopRekam();
                txt.setText("");
                rekam.setEnabled(true);
                stopr.setEnabled(false);
                putar.setEnabled(true);
                stopp.setEnabled(false);
            }
        });

        putar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startHasil();
                txt.setText("Sedang Memutar");
                rekam.setEnabled(false);
                stopr.setEnabled(false);
                putar.setEnabled(false);
                stopp.setEnabled(true);

            }
        });
        stopr = (Button)findViewById(R.id.button2);
        stopr.setEnabled(false);
        stopr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopHasil();
                txt.setText("");
                rekam.setEnabled(true);
                stopr.setEnabled(false);
                putar.setEnabled(true);
                stopp.setEnabled(false);
            }
        });


    }


    private void startRekam() {
        if (mr != null){
            mr.release();
        }
        File fout = new File(tempat);
        if (fout != null){
            fout.delete();
        }
        mr = new MediaRecorder();
        mr.setAudioSource(MediaRecorder.AudioSource.MIC);
        mr.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mr.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mr.setOutputFile(tempat);
        try {
            mr.prepare();
        } catch (IOException e){
            e.printStackTrace();
        }
        mr.start();
    }


    private void stopRekam() {
        if (mr != null){
            mr.stop();
            mr.release();
            mr = null;
        }
    }

    private void startHasil() {
        mp = new MediaPlayer();
        try {
            mp.setDataSource(tempat);
            mp.prepare();
            mp.start();
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    private void stopHasil() {
        if (mp != null){
            if (mp.isPlaying())
                mp.stop();
            mp.release();
            mp = null;
        }
    }


}
